# ATM-interface-with-JAVA-GUI

https://user-images.githubusercontent.com/76885324/170088231-41861ccf-43ab-4bb3-8cfd-ca2e85144e05.mp4

